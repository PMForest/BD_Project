INSERT warehouse (id, name, Warehouse_type_id, terade_price, price, quantity) VALUES
(5, 'Ножницы', 3, 1500, 750, 3),
(6, 'Пилки', 3, 75, 15, 150),
(7, 'Щипцы', 3, 1750, 850, 10),
(8, 'AirNail', 4, 7000, 4500, 3),
(9, 'Дезинфектор', 4, 25000, 7000, 2), 
(10, 'Лампа', 4, 2500, 750, 6);

SELECT * FROM new_schema1.warehouse;