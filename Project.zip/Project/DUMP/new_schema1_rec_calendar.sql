-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: new_schema1
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rec_calendar`
--

DROP TABLE IF EXISTS `rec_calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rec_calendar` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `users_id` int unsigned NOT NULL,
  `second_date` datetime DEFAULT NULL,
  `services_id` int unsigned NOT NULL,
  `services_id1` int unsigned NOT NULL,
  `services_id2` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_rec_calendar_users1_idx` (`users_id`),
  KEY `fk_rec_calendar_services1_idx1` (`services_id`),
  KEY `fk_rec_calendar_services2_idx` (`services_id1`),
  KEY `fk_rec_calendar_services3_idx` (`services_id2`),
  CONSTRAINT `fk_rec_calendar_services1` FOREIGN KEY (`services_id`) REFERENCES `services` (`id`),
  CONSTRAINT `fk_rec_calendar_services2` FOREIGN KEY (`services_id1`) REFERENCES `services` (`id`),
  CONSTRAINT `fk_rec_calendar_services3` FOREIGN KEY (`services_id2`) REFERENCES `services` (`id`),
  CONSTRAINT `fk_rec_calendar_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rec_calendar`
--

LOCK TABLES `rec_calendar` WRITE;
/*!40000 ALTER TABLE `rec_calendar` DISABLE KEYS */;
INSERT INTO `rec_calendar` VALUES (1,1,'2021-02-15 16:00:00',1,2,4),(2,3,'2021-01-14 19:00:00',2,4,3),(3,2,'2021-01-21 20:30:00',7,5,2),(4,5,'2021-02-14 20:00:00',9,2,4),(5,4,'2021-02-18 11:00:00',9,2,4),(6,6,'2021-03-02 13:30:00',8,2,6),(7,11,'2021-02-27 13:00:00',6,4,2),(8,9,'2021-01-25 12:30:00',5,9,4),(9,8,'2021-02-11 10:30:00',3,2,4),(10,6,'2021-03-02 13:30:00',7,3,1);
/*!40000 ALTER TABLE `rec_calendar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-25 20:58:15
